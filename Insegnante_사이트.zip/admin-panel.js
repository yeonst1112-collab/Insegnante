/* =====================================================================
   Insegnante — 관리자 페이지 (index.html 안의 '관리자' 화면)
   - 후기 관리: 승인 · 반려 · 삭제 (수강 인증 캡처 확인)
   - 정보 제보: 처리 완료 · 삭제 · 바로 선생님 정보 수정
   - 선생님 관리: 정보·강좌·링크 수정 / 새 선생님 추가 / 숨기기 / 되돌리기
   - 설정: 후기 공개 방식, 관리자 추가
   관리자 권한은 Firestore 보안 규칙(admins/{uid})으로도 확인되므로 화면만 고쳐서는 쓸 수 없음
   ===================================================================== */

let adminTab = 'reviews';
let adminReviewFilter = 'pending';
let adminCorrFilter = 'open';
let adminTeacherQuery = '';

const SUBSUBJECTS = {
  science: ['physics', 'chemistry', 'biology', 'earth', 'integrated_sci'],
  social: ['history_kr', 'history_world', 'society', 'ethics', 'geography', 'economy', 'law', 'integrated_soc']
};
const STATUS_KO = { pending: '승인 대기', approved: '공개됨', rejected: '반려됨' };

function openAdmin() {
  if (!isAdminUser()) {
    if (!isLoggedIn()) return requireLogin('관리자 계정으로 로그인해 주세요.', openAdmin);
    alert('관리자 계정만 들어갈 수 있어요.');
    return;
  }
  goScreen('admin-screen');
  renderAdmin();
}

function renderAdmin() {
  const who = document.getElementById('admin-who');
  if (who) who.textContent = currentProfile ? `${currentProfile.nickname} (${currentProfile.email}) · 관리자` : '';
  const tabs = [['reviews', '후기 관리'], ['corrections', '정보 제보'], ['teachers', '선생님 관리'], ['settings', '설정']];
  document.getElementById('admin-tabs').innerHTML = tabs.map(([k, v]) =>
    `<button class="chip${adminTab === k ? ' on' : ''}" onclick="adminTab='${k}';renderAdmin()">${v}</button>`).join('');
  const body = document.getElementById('admin-body');
  body.innerHTML = '<p class="empty-note">불러오는 중...</p>';
  ({ reviews: adminReviews, corrections: adminCorrections, teachers: adminTeachers, settings: adminSettings })[adminTab](body);
}

const adminDate = ts => {
  const d = ts && ts.toDate ? ts.toDate() : null;
  return d ? `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}` : '';
};
const tsMs = r => (r.createdAt && r.createdAt.toMillis ? r.createdAt.toMillis() : 0);

/* ---------------- 1) 후기 관리 ---------------- */
async function adminReviews(body) {
  const filters = [['pending', '승인 대기'], ['approved', '공개됨'], ['rejected', '반려됨'], ['all', '전체']];
  try {
    const q = fb.db.collection('reviews');
    const snap = adminReviewFilter === 'all' ? await q.limit(300).get() : await q.where('status', '==', adminReviewFilter).limit(300).get();
    const list = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => tsMs(b) - tsMs(a));
    body.innerHTML = `
      <div class="filter-row small">${filters.map(([k, v]) =>
        `<button class="chip${adminReviewFilter === k ? ' on' : ''}" onclick="adminReviewFilter='${k}';renderAdmin()">${v}</button>`).join('')}</div>
      <p class="all-count">${list.length}개</p>
      ${list.length ? list.map(r => `
        <div class="admin-item" id="ar-${esc(r.id)}">
          <div class="admin-row">
            <div class="admin-main">
              <div class="review-head"><b>${esc(r.teacher)}</b>
                <span class="rv-status ${esc(r.status)}">${STATUS_KO[r.status] || esc(r.status)}</span></div>
              <div class="review-head" style="margin-top:4px"><span class="stars">${stars(Number(r.rating) || 0)}</span>
                <span class="verified">진도 ${Math.round(r.progress)}%</span></div>
              <div class="review-course">📚 ${esc(r.course)}</div>
              <div class="review-text">${esc(r.text)}</div>
              <div class="review-meta">${esc(r.nickname || '익명')} · ${adminDate(r.createdAt)}</div>
              <div class="my-actions" style="margin-top:10px;flex-wrap:wrap">
                ${r.status !== 'approved' ? `<button class="mini-btn accent" onclick="adminSetReview(${jsArg(r.id)},'approved')">승인 (공개)</button>` : ''}
                ${r.status !== 'rejected' ? `<button class="mini-btn" onclick="adminSetReview(${jsArg(r.id)},'rejected')">반려 (비공개)</button>` : ''}
                <button class="mini-btn danger" onclick="adminDeleteReview(${jsArg(r.id)})">삭제</button>
              </div>
            </div>
            <div class="admin-proof">
              <div class="muted small">수강 인증 캡처 (진도 ${Math.round(r.progress)}% 이상인지 확인)</div>
              <img class="proof-preview" data-proof="${esc(r.id)}" alt="불러오는 중..." onclick="if(this.src)window.open(this.src)">
            </div>
          </div>
        </div>`).join('') : '<p class="empty-note">해당하는 후기가 없어요.</p>'}`;
    // 캡처는 관리자만 볼 수 있음 → 각각 불러오기
    body.querySelectorAll('img[data-proof]').forEach(async img => {
      try {
        const p = await fb.db.collection('proofs').doc(img.dataset.proof).get();
        if (p.exists) { img.src = p.data().image; img.style.display = 'block'; } else img.alt = '캡처 없음';
      } catch (e) { img.alt = '캡처를 불러오지 못했어요'; }
    });
  } catch (e) {
    console.error(e);
    body.innerHTML = adminErrorHTML(e);
  }
}

async function adminSetReview(id, status) {
  const msg = status === 'approved' ? '이 후기를 모든 사용자에게 공개할까요?' : '이 후기를 반려할까요? (다른 사용자에게 보이지 않아요)';
  if (!confirm(msg)) return;
  try {
    await fb.db.collection('reviews').doc(id).update({ status, reviewedAt: firebase.firestore.FieldValue.serverTimestamp(), reviewedBy: currentProfile.uid });
    renderAdmin();
  } catch (e) { alert('바꾸지 못했어요: ' + e.message); }
}

async function adminDeleteReview(id) {
  if (!confirm('이 후기를 완전히 삭제할까요? 되돌릴 수 없어요.')) return;
  try {
    await fb.db.collection('reviews').doc(id).delete();
    try { await fb.db.collection('proofs').doc(id).delete(); } catch (e) { }
    renderAdmin();
  } catch (e) { alert('삭제하지 못했어요: ' + e.message); }
}

/* ---------------- 2) 정보 제보 ---------------- */
async function adminCorrections(body) {
  const filters = [['open', '처리 전'], ['done', '처리 완료']];
  try {
    const snap = await fb.db.collection('corrections').where('status', '==', adminCorrFilter).limit(300).get();
    const list = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => tsMs(b) - tsMs(a));
    body.innerHTML = `
      <div class="filter-row small">${filters.map(([k, v]) =>
        `<button class="chip${adminCorrFilter === k ? ' on' : ''}" onclick="adminCorrFilter='${k}';renderAdmin()">${v}</button>`).join('')}</div>
      <p class="all-count">${list.length}개</p>
      ${list.length ? list.map(c => {
        const link = c.link && /^https?:\/\//i.test(c.link) ? c.link : '';
        const t = teachers.find(x => x.name === c.teacher);
        return `<div class="admin-item">
          <div class="review-head"><b>${esc(c.teacher)}</b><span class="rv-status pending">${esc(c.field || '제보')}</span></div>
          <div class="review-course">${esc(c.platform || '')} ${c.subject ? '· ' + esc(labelMap.subject[c.subject] || c.subject) : ''} · ${adminDate(c.createdAt)}</div>
          <div class="review-text">${esc(c.text)}</div>
          ${link ? `<div class="review-meta">참고: <a href="${esc(link)}" target="_blank" rel="noopener">${esc(link)}</a></div>` : ''}
          <div class="my-actions" style="margin-top:10px;flex-wrap:wrap">
            <button class="mini-btn accent" onclick='openTeacherEditor(${t ? jsArgSafe(JSON.stringify({ name: t.name, subject: t.subject, subSubject: t.subSubject })) : jsArgSafe(JSON.stringify({ name: c.teacher, subject: c.subject && labelMap.subject[c.subject] ? c.subject : 'math', isNew: true, platform: c.platform }))})'>${t ? '선생님 정보 수정' : '새 선생님으로 추가'}</button>
            ${c.status === 'open' ? `<button class="mini-btn" onclick="adminSetCorrection(${jsArg(c.id)},'done')">처리 완료</button>` : `<button class="mini-btn" onclick="adminSetCorrection(${jsArg(c.id)},'open')">처리 전으로</button>`}
            <button class="mini-btn danger" onclick="adminDeleteCorrection(${jsArg(c.id)})">삭제</button>
          </div>
        </div>`;
      }).join('') : '<p class="empty-note">해당하는 제보가 없어요.</p>'}`;
  } catch (e) { console.error(e); body.innerHTML = adminErrorHTML(e); }
}

async function adminSetCorrection(id, status) {
  try { await fb.db.collection('corrections').doc(id).update({ status }); renderAdmin(); }
  catch (e) { alert('바꾸지 못했어요: ' + e.message); }
}
async function adminDeleteCorrection(id) {
  if (!confirm('이 제보를 삭제할까요?')) return;
  try { await fb.db.collection('corrections').doc(id).delete(); renderAdmin(); }
  catch (e) { alert('삭제하지 못했어요: ' + e.message); }
}

/* ---------------- 3) 선생님 관리 ---------------- */
async function adminTeachers(body) {
  const q = norm(adminTeacherQuery);
  const seen = new Set();
  const list = teachers.filter(t => {
    const k = t.name + '|' + t.subject + '|' + t.subSubject;
    if (seen.has(k)) return false; seen.add(k);
    if (!q) return false;
    return norm(t.name).includes(q) || chosung(t.name).includes(q) || norm(t.platform).includes(q);
  }).slice(0, 40);

  let edits = [];
  try {
    const snap = await fb.db.collection('teacherEdits').get();
    edits = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.updatedAt && b.updatedAt.toMillis ? b.updatedAt.toMillis() : 0) - (a.updatedAt && a.updatedAt.toMillis ? a.updatedAt.toMillis() : 0));
  } catch (e) { console.warn(e); }

  body.innerHTML = `
    <div class="admin-toolbar">
      <input id="adm-tq" type="text" placeholder="수정할 선생님 이름·사이트 검색 (초성 가능)" value="${esc(adminTeacherQuery)}"
        oninput="adminTeacherQuery=this.value;clearTimeout(window.__atq);window.__atq=setTimeout(()=>{renderAdmin();setTimeout(()=>{const i=document.getElementById('adm-tq');if(i){i.focus();i.setSelectionRange(i.value.length,i.value.length)}},0)},250)">
      <button class="mini-btn accent" onclick="openTeacherEditor({ isNew: true, subject: 'math' })">+ 새 선생님 추가</button>
    </div>
    ${q ? (list.length ? list.map(t => `
      <div class="admin-item admin-row-compact">
        <div><b>${esc(t.name)}</b> <span class="muted small">${esc(t.platform)} · ${esc(labelMap.subject[t.subject])}${t.subSubject ? ' · ' + esc(labelMap.subSubject[t.subSubject] || '') : ''}</span>
          ${t.adminEdited ? '<span class="rv-status approved">수정됨</span>' : ''}</div>
        <div class="my-actions">
          <button class="mini-btn" onclick="openDetail(teachers.find(x=>x.name===${jsArg(t.name)}&&x.subject===${jsArg(t.subject)}))">보기</button>
          <button class="mini-btn accent" onclick='openTeacherEditor(${jsArgSafe(JSON.stringify({ name: t.name, subject: t.subject, subSubject: t.subSubject }))})'>수정</button>
        </div>
      </div>`).join('') : '<p class="empty-note">검색 결과가 없어요.</p>') : '<p class="empty-note">위에서 선생님을 검색하거나, 새 선생님을 추가하세요.</p>'}
    <div class="modal-section">
      <h4>관리자가 바꾼 내용 (${edits.length})</h4>
      ${edits.length ? edits.map(e => `
        <div class="admin-item admin-row-compact">
          <div><b>${esc(e.name)}</b> <span class="muted small">${esc(labelMap.subject[e.subject] || e.subject)}${e.subSubject ? ' · ' + esc(labelMap.subSubject[e.subSubject] || '') : ''}</span>
            <span class="rv-status ${e.hidden ? 'rejected' : e.isNew ? 'pending' : 'approved'}">${e.hidden ? '숨김' : e.isNew ? '새로 추가' : '정보 수정'}</span>
            <div class="muted small">${adminDate(e.updatedAt)} ${e.updatedByName ? '· ' + esc(e.updatedByName) : ''}</div></div>
          <div class="my-actions">
            <button class="mini-btn" onclick='openTeacherEditor(${jsArgSafe(JSON.stringify({ name: e.name, subject: e.subject, subSubject: e.subSubject || null }))})'>다시 수정</button>
            <button class="mini-btn danger" onclick="adminRevertEdit(${jsArg(e.id)})">되돌리기</button>
          </div>
        </div>`).join('') : '<p class="empty-note">아직 바꾼 내용이 없어요.</p>'}
    </div>`;
}

// 선생님 정보 편집 창
function openTeacherEditor(ref) {
  if (!isAdminUser()) return;
  if (typeof ref === 'string') ref = JSON.parse(ref);
  const t = ref.isNew ? null : teachers.find(x => x.name === ref.name && x.subject === ref.subject && (x.subSubject || null) === (ref.subSubject || null));
  const info = t ? (teacherDetails[t.name] || {}) : {};
  const subject = (t && t.subject) || ref.subject || 'math';
  const courses = t ? withPrices(t, info.courses || []).filter(c => !c.extra) : [];
  const courseLines = courses.map(c => [c.title, c.desc || '', c.p || '', c.d || '', c.b || ''].join(' | ')).join('\n');
  const subOpts = s => (SUBSUBJECTS[s] || []).map(k => `<option value="${k}"${(t ? t.subSubject : ref.subSubject) === k ? ' selected' : ''}>${labelMap.subSubject[k]}</option>`).join('');

  showModal(`
    <h3>${t ? esc(t.name) + ' 정보 수정' : '새 선생님 추가'}</h3>
    <p class="review-guide">저장하면 <b>모든 사용자에게 바로 반영</b>돼요. 잘못 바꿨다면 [선생님 관리 → 되돌리기]로 원래대로 돌릴 수 있어요.</p>
    <form class="form" onsubmit="saveTeacherEdit(event, ${jsArg(t ? 'edit' : 'new')})">
      <label>이름
        <input id="te-name" type="text" required maxlength="30" value="${esc(t ? t.name : (ref.name || ''))}" ${t ? 'readonly' : ''}>
      </label>
      <div class="form-row">
        <label>과목
          <select id="te-subject" ${t ? 'disabled' : ''} onchange="teSubjectChanged(this.value)">
            ${Object.entries(labelMap.subject).map(([k, v]) => `<option value="${k}"${subject === k ? ' selected' : ''}>${v}</option>`).join('')}
          </select>
        </label>
        <label>세부 과목
          <select id="te-sub" ${t ? 'disabled' : ''}><option value="">(없음)</option>${subOpts(subject)}</select>
        </label>
      </div>
      <div class="form-row">
        <label>사이트 <span class="muted">(여러 곳이면 " / "로 구분)</span>
          <input id="te-platform" type="text" required maxlength="40" value="${esc(t ? t.platform : (ref.platform || '메가스터디'))}" placeholder="예: 메가스터디 / EBS">
        </label>
        <label>성별
          <select id="te-gender">
            <option value="">모름</option>
            <option value="male"${t && t.gender === 'male' ? ' selected' : ''}>남자</option>
            <option value="female"${t && t.gender === 'female' ? ' selected' : ''}>여자</option>
          </select>
        </label>
      </div>
      <label>한 줄 소개
        <input id="te-desc" type="text" maxlength="200" value="${esc(t ? t.desc : '')}">
      </label>
      <label>강사 특징 <span class="muted">(한 줄에 하나씩)</span>
        <textarea id="te-features" rows="3">${esc((info.features || []).join('\n'))}</textarea>
      </label>
      <label>강좌 리스트 <span class="muted">(한 줄에 하나: 강좌명 | 설명 | 가격 | 수강기간 | 교재)</span>
        <textarea id="te-courses" rows="7" placeholder="2027 개념완성 | 수능 핵심 개념 정리 | 120,000원 | 150일 | 본교재 25,000원">${esc(courseLines)}</textarea>
      </label>
      <label>공식 강사 페이지 링크 <span class="muted">(비워 두면 기존 링크 사용)</span>
        <input id="te-link" type="url" maxlength="300" value="${esc(info.adminLink || '')}" placeholder="https://">
      </label>
      ${t ? `<label class="check"><input id="te-hidden" type="checkbox"> 이 선생님을 목록·추천에서 숨기기 (더 이상 강의하지 않는 경우)</label>` : ''}
      <p id="te-error" class="field-msg error"></p>
      <button class="link-btn as-btn" type="submit" id="te-submit">저장하기</button>
      <button class="ghost-btn" type="button" onclick="closeDetail()">취소</button>
    </form>`);
}

function teSubjectChanged(s) {
  const sel = document.getElementById('te-sub');
  sel.innerHTML = '<option value="">(없음)</option>' + (SUBSUBJECTS[s] || []).map(k => `<option value="${k}">${labelMap.subSubject[k]}</option>`).join('');
}

// Firestore 문서 ID로 쓸 수 있는 키 (이름·과목·세부과목)
function editKey(name, subject, subSubject) {
  return encodeURIComponent([name, subject, subSubject || 'none'].join('__')).replace(/%/g, '_').replace(/\./g, '_').slice(0, 200);
}

async function saveTeacherEdit(ev, mode) {
  ev.preventDefault();
  const err = document.getElementById('te-error');
  const btn = document.getElementById('te-submit');
  const name = document.getElementById('te-name').value.trim();
  const subject = document.getElementById('te-subject').value;
  const subSubject = document.getElementById('te-sub').value || null;
  const platform = document.getElementById('te-platform').value.trim();
  const link = document.getElementById('te-link').value.trim();
  if (!name || !platform) return (err.textContent = '이름과 사이트는 꼭 적어 주세요.');
  if ((subject === 'science' || subject === 'social') && !subSubject) return (err.textContent = '과학·사회는 세부 과목을 골라 주세요.');
  if (link && !/^https?:\/\//i.test(link)) return (err.textContent = '링크는 http:// 또는 https:// 로 시작해야 해요.');
  if (mode === 'new' && teachers.some(t => t.name === name && t.subject === subject && (t.subSubject || null) === subSubject))
    return (err.textContent = '같은 과목에 이미 있는 선생님이에요. [수정]을 이용해 주세요.');

  const courses = document.getElementById('te-courses').value.split('\n').map(l => l.trim()).filter(Boolean).map(l => {
    const [title, desc, p, d, b] = l.split('|').map(x => (x || '').trim());
    return { title, desc: desc || '', p: p || null, d: d || null, b: b || null };
  }).filter(c => c.title).slice(0, 30);
  const features = document.getElementById('te-features').value.split('\n').map(x => x.trim()).filter(Boolean).slice(0, 8);
  const hiddenEl = document.getElementById('te-hidden');

  const data = {
    name, subject, subSubject, platform,
    gender: document.getElementById('te-gender').value || null,
    desc: document.getElementById('te-desc').value.trim(),
    features, courses, link: link || null,
    hidden: !!(hiddenEl && hiddenEl.checked),
    isNew: mode === 'new',
    updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    updatedBy: currentProfile.uid,
    updatedByName: currentProfile.nickname
  };
  btn.disabled = true; btn.textContent = '저장 중...';
  try {
    await fb.db.collection('teacherEdits').doc(editKey(name, subject, subSubject)).set(data);
    applyTeacherEdit(data);
    refreshAfterTeacherChange();
    closeDetail();
    if (document.getElementById('admin-screen').classList.contains('active')) { adminTab = 'teachers'; renderAdmin(); }
    alert(data.hidden ? `${name} 선생님을 목록에서 숨겼어요.` : `${name} 선생님 정보를 저장했어요. 모든 사용자에게 반영돼요.`);
  } catch (e) {
    console.error(e);
    err.textContent = '저장하지 못했어요: ' + e.message;
    btn.disabled = false; btn.textContent = '저장하기';
  }
}

async function adminRevertEdit(id) {
  if (!confirm('이 변경을 지우고 원래 정보로 되돌릴까요? (화면을 새로고침해요)')) return;
  try { await fb.db.collection('teacherEdits').doc(id).delete(); location.reload(); }
  catch (e) { alert('되돌리지 못했어요: ' + e.message); }
}

/* ---------------- 4) 설정 ---------------- */
async function adminSettings(body) {
  let auto = false, admins = [];
  try { const d = await fb.db.collection('settings').doc('reviews').get(); auto = !!(d.exists && d.data().autoApprove === true); } catch (e) { }
  try {
    const snap = await fb.db.collection('admins').get();
    admins = snap.docs.map(d => ({ uid: d.id, ...d.data() }));
  } catch (e) { }
  body.innerHTML = `
    <div class="admin-item">
      <b>후기 공개 방식</b>
      <div class="my-actions" style="margin:10px 0;flex-wrap:wrap">
        <button class="mini-btn${!auto ? ' on' : ''}" onclick="adminSetAuto(false)">관리자 승인 후 공개 (추천)</button>
        <button class="mini-btn${auto ? ' on' : ''}" onclick="adminSetAuto(true)">작성 즉시 바로 공개</button>
      </div>
      <p class="muted small">${auto ? '지금: 학생이 쓴 후기가 바로 모든 사용자에게 공개돼요. 문제 있는 후기는 [후기 관리]에서 반려·삭제하세요.'
        : '지금: 학생이 쓴 후기는 [후기 관리 → 승인 대기]에 쌓이고, 수강 인증을 확인해 승인하면 공개돼요.'}</p>
    </div>
    <div class="admin-item">
      <b>관리자 계정</b>
      <div style="margin:8px 0">${admins.map(a => `<div class="muted small">· ${esc(a.name || a.email || a.uid)}${a.uid === currentProfile.uid ? ' (나)' : ''}</div>`).join('') || '<p class="muted small">목록을 불러오지 못했어요.</p>'}</div>
      <form class="form" onsubmit="adminAddAdmin(event)" style="margin-top:6px">
        <label>관리자 추가 <span class="muted">(먼저 이 사이트에 회원가입한 사람의 이메일)</span>
          <input id="adm-new" type="email" required placeholder="teacher@example.com">
        </label>
        <p id="adm-err" class="field-msg error"></p>
        <button class="mini-btn accent" type="submit">관리자로 지정</button>
      </form>
    </div>`;
}

async function adminSetAuto(on) {
  const msg = on ? '앞으로 작성되는 후기를 바로 공개할까요?' : '앞으로 작성되는 후기는 관리자 승인 후 공개할까요?';
  if (!confirm(msg)) return;
  try {
    await fb.db.collection('settings').doc('reviews').set({ autoApprove: on, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }, { merge: true });
    if (typeof reviewModeCache !== 'undefined') reviewModeCache = null;
    renderAdmin();
  } catch (e) { alert('저장하지 못했어요. 보안 규칙(firestore.rules)을 최신으로 게시했는지 확인해 주세요.'); }
}

async function adminAddAdmin(ev) {
  ev.preventDefault();
  const err = document.getElementById('adm-err');
  const email = document.getElementById('adm-new').value.trim().toLowerCase();
  try {
    const snap = await fb.db.collection('users').where('email', '==', email).limit(1).get();
    if (snap.empty) return (err.textContent = '이 이메일로 가입한 사용자가 없어요. 먼저 회원가입을 해 달라고 해 주세요.');
    const u = snap.docs[0];
    await fb.db.collection('admins').doc(u.id).set({ name: u.data().nickname || email, email, addedBy: currentProfile.uid });
    alert(email + ' 계정을 관리자로 지정했어요. 그 사람이 다시 로그인하면 관리자 메뉴가 보여요.');
    renderAdmin();
  } catch (e) { err.textContent = '지정하지 못했어요: ' + e.message; }
}

function adminErrorHTML(e) {
  return `<div class="notice-box">불러오지 못했어요. 관리자 계정으로 로그인했는지, 보안 규칙(firestore.rules)을 최신으로 게시했는지 확인해 주세요.<br><span class="muted small">${esc(e.message || '')}</span></div>`;
}

/* =====================================================================
   관리자가 바꾼 선생님 정보를 모든 사용자 화면에 반영 (teacherEdits 컬렉션)
   ===================================================================== */
function applyTeacherEdit(e) {
  const same = t => t.name === e.name && t.subject === e.subject && (t.subSubject || null) === (e.subSubject || null);
  if (e.hidden) {
    for (let i = teachers.length - 1; i >= 0; i--) if (same(teachers[i])) teachers.splice(i, 1);
    return;
  }
  let t = teachers.find(same);
  if (!t) {
    t = {
      name: e.name, subject: e.subject, subSubject: e.subSubject || null, platform: e.platform, partial: true,
      gender: null, paid: !/^\s*EBS\s*$/.test(e.platform), style: null, board: null, energy: null, note: null,
      priority: null, level: null, course: null, desc: e.desc || ''
    };
    teachers.push(t);
  }
  if (e.platform) t.platform = e.platform;
  if (e.desc) t.desc = e.desc;
  if (e.gender) t.gender = e.gender;
  t.adminEdited = true;
  const info = teacherDetails[e.name] = teacherDetails[e.name] || {};
  if (e.features && e.features.length) info.features = e.features;
  if (e.courses && e.courses.length) { info.courses = e.courses.map(c => ({ ...c, admin: true })); info.adminCourses = true; }
  if (e.link) info.adminLink = e.link;
}

function refreshAfterTeacherChange() {
  if (typeof profileCache !== 'undefined') profileCache.clear();
  if (typeof renderMyPanel === 'function') renderMyPanel();
  const cur = document.querySelector('.screen.active');
  if (cur && cur.id === 'all-screen' && typeof renderAllTeachers === 'function') renderAllTeachers();
}

async function loadTeacherEdits() {
  if (!initFirebase()) return;
  try {
    const snap = await fb.db.collection('teacherEdits').get();
    snap.docs.forEach(d => applyTeacherEdit(d.data()));
    if (!snap.empty) refreshAfterTeacherChange();
  } catch (e) { console.warn('관리자 수정 내용 불러오기 실패', e); }
}

// 관리자가 아닌데 관리자 화면에 있으면 처음 화면으로
onAuthChange(p => {
  const cur = document.querySelector('.screen.active');
  if (cur && cur.id === 'admin-screen' && !(p && p.isAdmin)) goScreen('start-screen');
  if (location.hash === '#admin') {
    if (p && p.isAdmin) { history.replaceState(null, '', location.pathname); openAdmin(); }
    else if (!p) { pendingAfterLogin = openAdmin; openLogin('관리자 계정으로 로그인해 주세요.'); }
  }
});

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', loadTeacherEdits);
else loadTeacherEdits();
