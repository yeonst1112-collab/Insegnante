/* =====================================================================
   Firebase 설정
   1) Firebase 콘솔 → 프로젝트 설정 → 내 앱(웹 </>) 에서 firebaseConfig 값을 복사
   2) 아래 null 을 지우고 복사한 객체를 붙여넣기
   자세한 방법은 FIREBASE_설정방법.md 참고
   ===================================================================== */

window.FIREBASE_CONFIG = null;

/* 예시 (실제 값으로 바꿔주세요)
window.FIREBASE_CONFIG = {
  apiKey: "AIza...",
  authDomain: "my-project.firebaseapp.com",
  projectId: "my-project",
  storageBucket: "my-project.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef"
};
*/
