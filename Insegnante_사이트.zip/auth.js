/* =====================================================================
   Insegnante — 로그인 시스템 (Firebase Authentication · 이메일/비밀번호)
   - 일반 사용자: 회원가입 → 로그인 → 후기 쓰기 · 내 후기 · 정보 제보
   - 관리자: Firestore 'admins/{uid}' 문서가 있는 계정 → 관리자 페이지 사용
   - 로그인하지 않아도 선생님 찾기 · 후기 읽기는 가능
   ===================================================================== */

let currentProfile = null;          // { uid, email, nickname, isAdmin } 또는 null
const authListeners = [];
let pendingAfterLogin = null;       // 로그인 성공 후 이어서 할 동작 (예: 후기 쓰기 창 다시 열기)

function onAuthChange(fn) { authListeners.push(fn); }
function isLoggedIn() { return !!currentProfile; }
function isAdminUser() { return !!(currentProfile && currentProfile.isAdmin); }

/* ---------- 로그인 상태 감시 ---------- */
function initAuth() {
  renderAuthMenu();
  if (!initFirebase()) return;
  fb.auth.onAuthStateChanged(async user => {
    if (user && user.isAnonymous) { try { await fb.auth.signOut(); } catch (e) { } return; }   // 예전 익명 로그인 정리
    if (user) {
      let nickname = '', isAdmin = false;
      try {
        const p = await fb.db.collection('users').doc(user.uid).get();
        if (p.exists) nickname = p.data().nickname || '';
      } catch (e) { console.warn('프로필 불러오기 실패', e); }
      try {
        const a = await fb.db.collection('admins').doc(user.uid).get();
        isAdmin = a.exists;
      } catch (e) { /* 관리자 아님 */ }
      const keep = currentProfile && currentProfile.uid === user.uid ? currentProfile.nickname : '';
      currentProfile = { uid: user.uid, email: user.email || '', nickname: nickname || keep || (user.email || '사용자').split('@')[0], isAdmin };
    } else {
      currentProfile = null;
    }
    renderAuthMenu();
    authListeners.forEach(fn => { try { fn(currentProfile); } catch (e) { console.error(e); } });
    if (currentProfile && pendingAfterLogin) { const f = pendingAfterLogin; pendingAfterLogin = null; f(); }
  });
}

/* ---------- 상단 메뉴: 로그인 버튼 / 닉네임 ---------- */
function renderAuthMenu() {
  const area = document.getElementById('gnb-auth');
  const adminBtn = document.getElementById('gnb-admin');
  if (adminBtn) adminBtn.style.display = isAdminUser() ? '' : 'none';
  if (!area) return;
  if (!currentProfile) {
    area.innerHTML = `<button class="gnb-login" onclick="openLogin()">로그인</button>`;
  } else {
    area.innerHTML = `<button class="gnb-user" onclick="openAccount()">
      ${isAdminUser() ? '<span class="admin-badge">관리자</span>' : ''}${esc(currentProfile.nickname)}님 ▾</button>`;
  }
}

/* 로그인이 필요한 기능 앞에서 호출: 로그인 안 했으면 로그인 창을 띄우고 false */
function requireLogin(message, after) {
  if (isLoggedIn()) return true;
  if (!firebaseEnabled()) { showModal(`<h3>로그인이 필요해요</h3>${NO_SERVER_HTML}`); return false; }
  pendingAfterLogin = after || null;
  openLogin(message);
  return false;
}

/* ---------- 로그인 / 회원가입 창 ---------- */
let authTab = 'login';

function openLogin(message, tab) {
  if (tab) authTab = tab;
  if (typeof toggleSearch === 'function') toggleSearch(false);
  if (!firebaseEnabled()) { showModal(`<h3>로그인</h3>${NO_SERVER_HTML}`); return; }
  showModal(`
    <h3>${authTab === 'login' ? '로그인' : '회원가입'}</h3>
    ${message ? `<p class="review-guide">${esc(message)}</p>` : ''}
    <div class="auth-tabs">
      <button class="${authTab === 'login' ? 'on' : ''}" onclick="authTab='login';openLogin(${jsArg(message || '')})">로그인</button>
      <button class="${authTab === 'signup' ? 'on' : ''}" onclick="authTab='signup';openLogin(${jsArg(message || '')})">회원가입</button>
    </div>
    <form class="form" onsubmit="${authTab === 'login' ? 'doLogin(event)' : 'doSignup(event)'}">
      <label>이메일
        <input id="au-email" type="email" required autocomplete="email" placeholder="example@email.com">
      </label>
      <label>비밀번호 <span class="muted">${authTab === 'signup' ? '(6자 이상)' : ''}</span>
        <input id="au-pw" type="password" required minlength="6" autocomplete="${authTab === 'login' ? 'current-password' : 'new-password'}">
      </label>
      ${authTab === 'signup' ? `
      <label>비밀번호 확인
        <input id="au-pw2" type="password" required minlength="6" autocomplete="new-password">
      </label>
      <label>닉네임 <span class="muted">(2~12자, 후기에 표시돼요)</span>
        <input id="au-nick" type="text" required minlength="2" maxlength="12" placeholder="예: 수능열공러">
      </label>` : ''}
      <p id="au-error" class="field-msg error"></p>
      <button class="link-btn as-btn" type="submit" id="au-submit">${authTab === 'login' ? '로그인' : '가입하기'}</button>
      ${authTab === 'login' ? `<button class="ghost-btn" type="button" onclick="sendReset()">비밀번호를 잊었어요</button>` : ''}
    </form>`);
  setTimeout(() => { const e = document.getElementById('au-email'); if (e) e.focus(); }, 50);
}

// Firebase 오류 코드를 쉬운 말로
function authErrorText(e) {
  const code = (e && e.code) || '';
  const map = {
    'auth/email-already-in-use': '이미 가입된 이메일이에요. 로그인해 주세요.',
    'auth/invalid-email': '이메일 형식이 올바르지 않아요.',
    'auth/weak-password': '비밀번호는 6자 이상이어야 해요.',
    'auth/wrong-password': '이메일 또는 비밀번호가 맞지 않아요.',
    'auth/user-not-found': '이메일 또는 비밀번호가 맞지 않아요.',
    'auth/invalid-credential': '이메일 또는 비밀번호가 맞지 않아요.',
    'auth/invalid-login-credentials': '이메일 또는 비밀번호가 맞지 않아요.',
    'auth/too-many-requests': '시도가 너무 많아요. 잠시 후 다시 시도해 주세요.',
    'auth/network-request-failed': '인터넷 연결을 확인해 주세요.',
    'auth/operation-not-allowed': 'Firebase에서 "이메일/비밀번호" 로그인이 아직 켜져 있지 않아요. (관리자 설정 필요)',
    'auth/unauthorized-domain': '이 주소에서는 로그인할 수 없어요. Firebase "승인된 도메인"에 사이트 주소를 추가해 주세요.'
  };
  return map[code] || ('문제가 생겼어요. 잠시 후 다시 시도해 주세요. (' + (code || e.message) + ')');
}

async function doLogin(ev) {
  ev.preventDefault();
  const err = document.getElementById('au-error');
  const btn = document.getElementById('au-submit');
  const email = document.getElementById('au-email').value.trim();
  const pw = document.getElementById('au-pw').value;
  btn.disabled = true; btn.textContent = '로그인 중...';
  try {
    await fb.auth.signInWithEmailAndPassword(email, pw);
    closeDetail();
  } catch (e) {
    err.textContent = authErrorText(e);
    btn.disabled = false; btn.textContent = '로그인';
  }
}

async function doSignup(ev) {
  ev.preventDefault();
  const err = document.getElementById('au-error');
  const btn = document.getElementById('au-submit');
  const email = document.getElementById('au-email').value.trim();
  const pw = document.getElementById('au-pw').value;
  const pw2 = document.getElementById('au-pw2').value;
  const nickname = document.getElementById('au-nick').value.trim();
  if (pw !== pw2) return (err.textContent = '비밀번호 확인이 일치하지 않아요.');
  if (nickname.length < 2 || nickname.length > 12) return (err.textContent = '닉네임은 2~12자로 정해 주세요.');
  btn.disabled = true; btn.textContent = '가입 중...';
  try {
    const cred = await fb.auth.createUserWithEmailAndPassword(email, pw);
    await fb.db.collection('users').doc(cred.user.uid).set({
      nickname, email: cred.user.email || email.toLowerCase(), createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    // onAuthStateChanged가 프로필을 읽기 전에 저장이 끝나도록 한 번 더 갱신
    currentProfile = { uid: cred.user.uid, email, nickname, isAdmin: false };
    renderAuthMenu();
    closeDetail();
    if (pendingAfterLogin) { const f = pendingAfterLogin; pendingAfterLogin = null; f(); }
  } catch (e) {
    err.textContent = authErrorText(e);
    btn.disabled = false; btn.textContent = '가입하기';
  }
}

async function sendReset() {
  const err = document.getElementById('au-error');
  const email = document.getElementById('au-email').value.trim();
  if (!email) return (err.textContent = '비밀번호를 다시 정할 이메일을 먼저 적어 주세요.');
  try {
    await fb.auth.sendPasswordResetEmail(email);
    err.className = 'field-msg ok';
    err.textContent = '비밀번호 재설정 메일을 보냈어요. 메일함을 확인해 주세요.';
  } catch (e) { err.className = 'field-msg error'; err.textContent = authErrorText(e); }
}

async function doLogout() {
  if (!confirm('로그아웃할까요?')) return;
  try { await fb.auth.signOut(); } catch (e) { }
  currentProfile = null;
  renderAuthMenu();
  closeDetail();
  const cur = document.querySelector('.screen.active');
  if (cur && cur.id === 'admin-screen') goScreen('start-screen');
}

/* ---------- 내 계정 창 ---------- */
function openAccount() {
  if (!currentProfile) return openLogin();
  showModal(`
    <h3>${esc(currentProfile.nickname)}님</h3>
    <div class="teacher-platform">${esc(currentProfile.email)}${isAdminUser() ? ' · <b>관리자</b>' : ''}</div>
    <div class="modal-actions">
      ${isAdminUser() ? '<button class="link-btn as-btn" onclick="closeDetail();openAdmin()">관리자 페이지</button>' : ''}
      <button class="ghost-btn" onclick="openMyReviews()">내가 쓴 수강 후기</button>
      <button class="ghost-btn" onclick="openMyReports()">내가 보낸 제보</button>
      <button class="ghost-btn" onclick="openMyTeachers()">내 선생님</button>
      <button class="ghost-btn" onclick="openNicknameEdit()">닉네임 바꾸기</button>
      <button class="ghost-btn" onclick="doLogout()">로그아웃</button>
    </div>`);
}

function openNicknameEdit() {
  showModal(`
    <h3>닉네임 바꾸기</h3>
    <form class="form" onsubmit="saveNickname(event)">
      <label>새 닉네임 <span class="muted">(2~12자)</span>
        <input id="nk-new" type="text" required minlength="2" maxlength="12" value="${esc(currentProfile.nickname)}">
      </label>
      <p id="nk-error" class="field-msg error"></p>
      <button class="link-btn as-btn" type="submit">저장</button>
      <button class="ghost-btn" type="button" onclick="openAccount()">← 돌아가기</button>
    </form>`);
}

async function saveNickname(ev) {
  ev.preventDefault();
  const v = document.getElementById('nk-new').value.trim();
  const err = document.getElementById('nk-error');
  if (v.length < 2 || v.length > 12) return (err.textContent = '닉네임은 2~12자로 정해 주세요.');
  try {
    await fb.db.collection('users').doc(currentProfile.uid).set({ nickname: v }, { merge: true });
    currentProfile.nickname = v;
    renderAuthMenu();
    openAccount();
  } catch (e) { err.textContent = '저장하지 못했어요. 잠시 후 다시 시도해 주세요.'; }
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAuth);
else initAuth();
